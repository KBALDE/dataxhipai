import logging

import azure.functions as func



import urllib.request
import json
import os
import ssl
import ast


def query_inference_url(userId):
    def allowSelfSignedHttps(allowed):
    # bypass the server certificate verification on client side
        if allowed and not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, 
                                                                           '_create_unverified_context', None):
            ssl._create_default_https_context = ssl._create_unverified_context

    allowSelfSignedHttps(True) # this line is needed if you use self-signed certificate in your scoring service.

    # Request data goes here
    data={}
    data["userId"]=userId
    
    body = str.encode(json.dumps(data))
    
    #body = json.dumps(data)
    
    url = 'http://118795b5-6f88-4795-a8c9-afdb53f2b858.eastus2.azurecontainer.io/score'
    api_key = 'D659AM1lPUtvre2EKcveZE9qL7uv6Yo3' # Replace this with the API key for the web service
    headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}
    
    req = urllib.request.Request(url, body, headers)
    response = urllib.request.urlopen(req)

    result = response.read()
    result=ast.literal_eval(result.decode("utf8"))
    return result





def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
    except ValueError:
        pass
    else:
        userid = req_body.get('userId')

    #if userid:
    reco_list = json.dumps(query_inference_url(userid))
    return func.HttpResponse(reco_list)
    
    #else:
    #    return func.HttpResponse(
    #         "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
    #         status_code=200
    #    )
