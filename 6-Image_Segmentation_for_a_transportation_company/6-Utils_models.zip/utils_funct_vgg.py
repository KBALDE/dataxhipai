
# LIBS
import tensorflow as tf
import numpy as np

from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Dropout 
from tensorflow.keras.layers import Conv2DTranspose
from tensorflow.keras.layers import concatenate

from tensorflow.keras.preprocessing import image
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from tensorflow.keras.callbacks import  EarlyStopping

import imageio
import os
import seaborn as sns


def readDataImages(image_list, mask_list):
    target_size=(224, 224)
    img_list=[]
    for i in range(len(image_list)):
    
        img = imageio.imread(image_list[i])
        img = img[:,:, :3]                 # RETRIEVE THE three first channels 
        img = tf.image.convert_image_dtype(img, tf.float32)
        img = tf.image.resize(img, target_size )
        img_list.append(img)
        
    imask_list=[]
  
    for i in range(len(mask_list)):
        
        img = image.img_to_array(image.load_img(f'{mask_list[i]}', 
                                            color_mode="grayscale", 
                                            target_size=target_size) )
        imask_list.append(img)
            
        
    img_array= np.asarray(img_list)
    
    mask_array= np.asarray(imask_list)
    mask_array= tf.math.reduce_max(mask_array, axis=-1, keepdims=True)
    
    return img_array, mask_array

  
def seg_gen(imagine, maskim):
    
    image = imagine

    img=tf.cast(maskim, dtype='int32')
    mask = np.zeros((img.shape[0], img.shape[1], 8))
    
    for i in range(-1, 34):
        if i in cats['void']:
            mask[:,:,0] = np.logical_or(mask[:,:,0],(img==i)[:,:,0])
        elif i in cats['flat']:
            mask[:,:,1] = np.logical_or(mask[:,:,1],(img==i)[:,:,0])
        elif i in cats['construction']:
            mask[:,:,2] = np.logical_or(mask[:,:,2],(img==i)[:,:,0])
        elif i in cats['object']:
            mask[:,:,3] = np.logical_or(mask[:,:,3],(img==i)[:,:,0])
        elif i in cats['nature']:
            mask[:,:,4] = np.logical_or(mask[:,:,4],(img==i)[:,:,0])
        elif i in cats['sky']:
            mask[:,:,5] = np.logical_or(mask[:,:,5],(img==i)[:,:,0])
        elif i in cats['human']:
            mask[:,:,6] = np.logical_or(mask[:,:,6],(img==i)[:,:,0])
        elif i in cats['vehicle']:
            mask[:,:,7] = np.logical_or(mask[:,:,7],(img==i)[:,:,0])
            
    return image, mask


def seg_gen_unet(imagine, maskim):
    
    image = imagine

    img=tf.cast(maskim, dtype='int32')
    mask = np.zeros((img.shape[0], img.shape[1], 8))
    
    for i in range(-1, 34):
        if i in cats['void']:
            mask[:,:,0] = 1 * np.logical_or(mask[:,:,0],(img==i)[:,:,0])
        elif i in cats['flat']:
            mask[:,:,1] = 1 * np.logical_or(mask[:,:,1],(img==i)[:,:,0])
        elif i in cats['construction']:
            mask[:,:,2] = 2 * np.logical_or(mask[:,:,2],(img==i)[:,:,0])
        elif i in cats['object']:
            mask[:,:,3] = 3 * np.logical_or(mask[:,:,3],(img==i)[:,:,0])
        elif i in cats['nature']:
            mask[:,:,4] = 4 * np.logical_or(mask[:,:,4],(img==i)[:,:,0])
        elif i in cats['sky']:
            mask[:,:,5] = 5 * np.logical_or(mask[:,:,5],(img==i)[:,:,0])
        elif i in cats['human']:
            mask[:,:,6] = 6 * np.logical_or(mask[:,:,6],(img==i)[:,:,0])
        elif i in cats['vehicle']:
            mask[:,:,7] = 7 * np.logical_or(mask[:,:,7],(img==i)[:,:,0])
            
    mask= tf.math.reduce_max(mask, axis=-1, keepdims=True)
        
    return image, mask

def stackDataSets(image_arr, mask_arr):
    stack_img=[]
    stack_mask=[]
  
    for im, ma in zip(image_arr, mask_arr):
        a=seg_gen_unet(im, ma)
        stack_img.append(a[0])
        stack_mask.append(a[1])
      
    image_stack= tf.stack(stack_img, axis=0)  
    mask_stack= tf.stack(stack_mask, axis=0)
  
    return  image_stack, mask_stack


# FOR DISPLAY PREDICTIONS

def create_mask(pred_mask):
    pred_mask = tf.argmax(pred_mask, axis=-1)
    pred_mask = pred_mask[..., tf.newaxis]
    return pred_mask[0]

import matplotlib.pyplot as plt

def display(display_list):
    plt.figure(figsize=(15, 15))

    title = ['Input Image', 'True Mask', 'Predicted Mask']

    for i in range(len(display_list)):
        plt.subplot(1, len(display_list), i+1)
        plt.title(title[i])
        plt.imshow(tf.keras.preprocessing.image.array_to_img(display_list[i]))
        plt.axis('off')
    plt.show()
    
    
def show_predictions_unet(dataset=None, num=1):
    """
    Displays the first image of each of the num batches
    """
    if dataset:
        for image, mask in dataset.take(num):
            pred_mask = unet.predict(image)
            display([image[0], mask[0], create_mask(pred_mask)])
    else:
        display([sample_image, sample_mask,
             create_mask(unet.predict(sample_image[tf.newaxis, ...]))])
        

# CATEGORIES TO CONSIDER IN THE DATA
cats = {'void': [0, 1, 2, 3, 4, 5, 6],
 'flat': [7, 8, 9, 10],
 'construction': [11, 12, 13, 14, 15, 16],
 'object': [17, 18, 19, 20],
 'nature': [21, 22],
 'sky': [23],
 'human': [24, 25],
 'vehicle': [26, 27, 28, 29, 30, 31, 32, 33, -1]}

class_names=[x for x in cats.keys()]


import albumentations as A
import cv2

transform = A.Compose([
    A.HorizontalFlip(p=1),
    A.RandomBrightnessContrast(p=0.1),
    A.Rotate(limit=5)
])

def augConcat(image_array, mask_array):
    aug=transform(image=image_array, mask=mask_array)
    aug_image=np.concatenate((image_array, aug['image']), axis=0)
    aug_mask=np.concatenate((mask_array, aug['mask']), axis=0)
    return aug_image, aug_mask


# Reshape segmentation masks
def mask8_old(annotation):

    annotation = tf.cast(annotation, 
                           dtype = tf.int32)
    stack_list = []  
    for c in range(len(class_names)):
        mask = tf.equal(annotation[:,:,0], tf.constant(c))
        stack_list.append(tf.cast(mask, dtype=tf.int32))
    annotation = tf.stack(stack_list, axis=2)
    return annotation

# Reshape segmentation masks
def mask8(image, annotation):

    annotation = tf.cast(annotation, 
                           dtype = tf.int32)
    stack_list = []  
    for c in range(len(class_names)):
        mask = tf.equal(annotation[:,:,0], tf.constant(c))
        stack_list.append(tf.cast(mask, dtype=tf.int32))
    annotation = tf.stack(stack_list, axis=2)
    return image, annotation


# PREDICTION FUCNTION UTILITIES

def compute_metrics(y_true, y_pred , n_classes):
    '''
    Computes IOU and Dice Score.
  
    Args:
      y_true (tensor) - ground truth label map
      y_pred (tensor) - predicted label map
    '''
    
    class_wise_iou = []
    class_wise_dice_score = []
  
    smoothening_factor = 0.00001
  
    for i in range(n_classes):
        intersection = np.sum((y_pred == i) * (y_true == i))
        y_true_area = np.sum((y_true == i))
        y_pred_area = np.sum((y_pred == i))
        combined_area = y_true_area + y_pred_area
      
        iou = (intersection + smoothening_factor) / (combined_area - intersection + smoothening_factor)
        class_wise_iou.append(np.round(iou, 4))
      
        dice_score =  2 * ((intersection + smoothening_factor) / (combined_area + smoothening_factor))
        class_wise_dice_score.append(np.round(dice_score,4))
  
    return class_wise_iou, class_wise_dice_score


def give_color_to_annotation(annotation, n_classes):
  '''
  Converts a 2-D annotation to a numpy array with shape (height, width, 3) where
  the third axis represents the color channel. The label values are multiplied by
  255 and placed in this axis to give color to the annotation

  Args:
    annotation (numpy array) - label map array
  
  Returns:
    the annotation array with an additional color channel/axis
  '''
  seg_img = np.zeros( (annotation.shape[0],annotation.shape[1], 3) ).astype('float')
  
  for c in range(n_classes):
    segc = (annotation == c)
    seg_img[:,:,0] += segc*( colors[c][0] * 255.0)
    seg_img[:,:,1] += segc*( colors[c][1] * 255.0)
    seg_img[:,:,2] += segc*( colors[c][2] * 255.0)
  
  return seg_img

# PRED VIZ
def show_predictions(image, labelmaps, titles, iou_list, dice_score_list):
    '''
    Displays the images with the ground truth and predicted label maps
  
    Args:
      image (numpy array) -- the input image
      labelmaps (list of arrays) -- contains the predicted and ground truth label maps
      titles (list of strings) -- display headings for the images to be displayed
      iou_list (list of floats) -- the IOU values for each class
      dice_score_list (list of floats) -- the Dice Score for each vlass
    '''
  
    true_img = give_color_to_annotation(np.reshape(labelmaps[1], (224, 224)), n_classes=8)
    pred_img = give_color_to_annotation(labelmaps[0], n_classes=8)
    
    #true_img = np.reshape( labelmaps[1], (224, 224) )
    #pred_img = labelmaps[0]
  
    image = image + 1
    image = image * 127.5
    images = np.uint8([image, pred_img, true_img])
  
    metrics_by_id = [(idx, iou, dice_score) for idx, (iou, 
                                                      dice_score) in enumerate(zip(iou_list, 
                                                                                   dice_score_list)) 
                     if iou > 0.0]
    metrics_by_id.sort(key=lambda tup: tup[1], reverse=True)  # sorts in place
    
    display_string_list = ["{}: IOU: {} Dice Score: {}".format(
        class_names[idx], iou, dice_score) for idx, iou, dice_score in metrics_by_id]
   
    display_string = "\n\n".join(display_string_list) 
  
    plt.figure(figsize=(15, 4))
  
    for idx, im in enumerate(images):
        plt.subplot(1, 3, idx+1)
        if idx == 1:
            plt.xlabel(display_string)
        plt.xticks([])
        plt.yticks([])
        plt.title(titles[idx], fontsize=12)
        plt.imshow(im)
        
        
main_path = './gtFine/'
train_path_image='train_images/'
train_path_mask='train_masks/'

val_path_image='val_images/'
val_path_mask='val_masks/'

test_path_image = 'test_images/'
test_path_mask = 'test_masks/'


def getFilesPathsList(main_path, path_image, path_mask ):
    
    image_list = [os.path.join(main_path, path_image)+i 
                  for i in sorted(os.listdir(os.path.join(main_path, path_image)))]
    
    mask_list = [os.path.join(main_path, path_mask)+i 
                 for i in sorted(os.listdir(os.path.join(main_path, path_mask)))]
    
    return image_list , mask_list
